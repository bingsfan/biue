# 因“课题组经费有限”，信息科学为简洁版，详细版如下
<div align=center>
<img src="https://github.com/user-attachments/assets/d1b99b19-9f20-4c0a-bea2-0af5bf4db98c">
<img src="https://github.com/user-attachments/assets/8ef7bccc-c982-49c0-9b39-15409af78256">
<img src="https://github.com/user-attachments/assets/f4b041e0-4f81-496a-9248-6df6979b6c91">
<img src="https://github.com/user-attachments/assets/a9356f31-b99f-424a-8e9c-24ed3e3f41f3">
<img src="https://github.com/user-attachments/assets/0980e616-5062-4d5e-a72d-938994d71a16">
<img src="https://github.com/user-attachments/assets/89a43b33-0c71-46fe-b44f-aeb687d20236">
<img src="https://github.com/user-attachments/assets/4fd73fc4-d4de-49c7-9701-3afb0c283afb">
<img src="https://github.com/user-attachments/assets/c2750147-bf10-4498-9a73-738d75e3c55a">
<img src="https://github.com/user-attachments/assets/a17ae9e4-456e-4efc-9080-78a396cf4aed">
<img src="https://github.com/user-attachments/assets/0541173a-8f9c-457d-97ef-1240335394a6">
<img src="https://github.com/user-attachments/assets/eea6111b-5e3b-4986-af88-4c156a4e2971">
<img src="https://github.com/user-attachments/assets/5bfba222-79b7-4353-92bb-89d76a4490d7">
<img src="https://github.com/user-attachments/assets/8117fbb5-76da-405f-84c4-a38e55b5c56a">
<img src="https://github.com/user-attachments/assets/b4c32919-1151-4c23-87eb-a69ec1cf1a8c">
</div>

未完待续……

**如需引用上述文字等内容，则请注明来源出处，采用以下的引用格式，请勿侵权。**

引用格式：方城亮. 基于深度强化学习的无人机武器目标分配与航路规划研究[D]. 西北工业大学, 2024.
